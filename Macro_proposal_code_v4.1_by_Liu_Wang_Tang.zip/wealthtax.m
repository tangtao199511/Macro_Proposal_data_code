%main program of Proposal

%%%%% CopyRight %%%%%
%Code by Tao Tang.
%Thanks for RuoShui Liu and YinSu Wang's support and help!
%Thanks for Professor Zeng's instruction.

%%%%%%%%%%  Set up of the model  %%%%%%%%%%
%%%%%%%%%%  and Import data  %%%%%%%%%%

clear variables;
clc;
t=cputime;
%%parameters and setups%%

N = 12049;% Number of individuals
G = 10; %Number of groups

ID = 1:N; %ID of individuals

L = zeros(N,3); % labor, hours of working
L(:,1) = 0.3; %labor, hours of working
wagerate = zeros(N,2); % wage rate of individuals
r = zeros(1,2); % return rate of saving

r(1) = 0.0301; %From Data of Shibor in 2016
r(2) = 0.0301;

%t = linspace(0,0.5,G); Tax rate
Wealth = zeros(N,3); % Wealth before and after tax before policy
s = zeros(N,1); % amount of saving
T = zeros(N,2); % Tax amount
WAGE = zeros(N,3); %WAGE of individuals

%alpha = 0.3; % preference

%%%%%% get data %%%%%%

DATA = zeros(N,9);
DATA = xlsread('alldata.xlsx'); %For read data from excel is very time consuming
%Wealth = xlsread('wealth.xlsx'); % Thus here I collapsed the dataset into one excel
%s = xlsread('save.xlsx');  % file to improve effeciency.
%T = xlsread('tax.xlsx');
%WAGE = xlsread('wage.xlsx');

Wealth = DATA(:,1:3);
s = DATA(:,4);
T = DATA(:,5:6);
WAGE = DATA(:,7:9);

WealthD = zeros(N,3);

WealthD(:,1) = sort(Wealth(:,1),'descend'); %sort the Wealth by descending.
WealthD(:,2) = sort(Wealth(:,2),'descend');
WealthD(:,3) = sort(Wealth(:,2),'descend');


%n = floor(N/G);  %Grouping the data, Not finished yet.

%for i = 1:G-1
   % T((i-1)*n+1:i*n,1) = W((i-1)*n+1:i*n,1)*t(G-i+1);
%end

%T((G-1)*n+1:N,1)= W((G-1)*n+1:N,1)*t(1);

%WA(:,1) = WB(:,1)-T(:,1);
%delta = W(:,1) - WA(:,1);

%%% HistoGram %%%

%Wagepdf = pdf(pd,WAGE(:,1));
%histogram(WAGE(:,1),[0 0:10000:600000]);




%%%%Sum up the wealth one by one%%%%%%

SumWealth = zeros(N,3);
WealthA = zeros(N,3);

WealthA(:,1) = sort(Wealth(:,1),'ascend'); %sort the Wealth by Ascending.
WealthA(:,2) = sort(Wealth(:,2),'ascend');% Ascending.
WealthA(:,3) = sort(Wealth(:,3),'ascend');% Ascending.

SumWealthA(1,1) = WealthA(1,1);
SumWealthA(1,2) = WealthA(1,2);
SumWealthA(1,3) = WealthA(1,3);

for i = 1:N-1
    SumWealthA(i+1,1) = SumWealthA(i,1) + WealthA(i+1,1); %Sum up the wealth
end

for i = 1:N-1
    SumWealthA(i+1,2) = SumWealthA(i,2) + WealthA(i+1,2);
end

for i = 1:N-1
    SumWealthA(i+1,3) = SumWealthA(i,3) + WealthA(i+1,3);
end

norSumWealthA(:,1) = SumWealthA(:,1)/(SumWealthA(N,1)); %Normalized sum distribution Before tax ascending.
norSumWealthA(:,2) = SumWealthA(:,2)/(SumWealthA(N,2)); %Normalized sum distribution After tax ascending.
norSumWealthA(:,3) = SumWealthA(:,3)/(SumWealthA(N,3)); %Normalized sum distribution After tax and policy ascending.

display('aaaaa')

%Sum up the wage one by one

SumWAGE = zeros(N,3);
WAGEA = zeros(N,3);

WAGEA(:,1) = sort(WAGE(:,1),'ascend'); %sort the WAGE by Ascending.
WAGEA(:,2) = sort(WAGE(:,2),'ascend');% Ascending.
WAGEA(:,3) = sort(WAGE(:,3),'ascend');% Ascending.

SumWAGEA(1,1) = WAGEA(1,1);
SumWAGEA(1,2) = WAGEA(1,2);
SumWAGEA(1,3) = WAGEA(1,3);

for i = 1:N-1
    SumWAGEA(i+1,1) = SumWAGEA(i,1) + WAGEA(i+1,1); %Sum up the wage
end

for i = 1:N-1
    SumWAGEA(i+1,2) = SumWAGEA(i,2) + WAGEA(i+1,2);
end

for i = 1:N-1
    SumWAGEA(i+1,3) = SumWAGEA(i,3) + WAGEA(i+1,3);
end

norSumWAGEA(:,1) = SumWAGEA(:,1)/(SumWAGEA(N,1)); %Normalized sum distribution Before tax ascending.
norSumWAGEA(:,2) = SumWAGEA(:,2)/(SumWAGEA(N,2)); %Normalized sum distribution After tax ascending.
norSumWAGEA(:,3) = SumWAGEA(:,3)/(SumWAGEA(N,3)); %Normalized sum distribution After tax and policy ascending.

%Sum up population one by one

norPop = ID(1,:)/N; %Population Distribution
norPop = norPop';

% Plot the figure
figure(1);
plot(WealthD(:,1));
title('Wealth distribution BEFORE Tax');
axis([0 13557 -1350000 100000000])

figure(2);
plot(WealthD(:,2));
title('Wealth distribution AFTER Tax');
axis([0 13557 -1350000 5000000])

figure(3);
plot(WealthD(:,3));
title('Wealth AFTER Tax and Policy');
axis([0 13557 -1350000 5000000])

figure(4);
plot(norPop,norPop,norPop,norSumWealthA(:,1),'b',norPop,norSumWealthA(:,2),'--g',norPop,norSumWealthA(:,3),'--r');
title('Lorenz Curve by Wealth');
legend('Equal Line','Before Tax','After Tax','After Tax and Policy');
axis square
grid on
axis ([0 1 -0.1 1]);
xlabel('Population'); ylabel('Wealth')
display('bbbbb')

figure(5);
plot(norPop,norPop,norPop,norSumWAGEA(:,1),'b',norPop,norSumWAGEA(:,2),'--g',norPop,norSumWAGEA(:,3),'--r');
title('Lorenz Curve by WAGE');
legend('Equal Line','Before Tax','After Tax','After Tax and Policy');
axis square
grid on
axis ([0 1 0 1]);
%axis auto
xlabel('Population'); ylabel('Wage')
%calculate the Gini Coefficient by Wealth data

GiniWealth = zeros(1,3);
GiniWealth(1) = sum(norPop-norSumWealthA(:,1))/sum(norPop);
GiniWealth(2) = sum(norPop-norSumWealthA(:,2))/sum(norPop);
GiniWealth(3) = sum(norPop-norSumWealthA(:,3))/sum(norPop);
format long
GiniWealth

%calculate the Gini Coefficient by Wealth data
GiniWAGE = zeros(1,3);
GiniWAGE(1) = sum(norPop-norSumWAGEA(:,1))/sum(norPop);
GiniWAGE(2) = sum(norPop-norSumWAGEA(:,2))/sum(norPop);
GiniWAGE(3) = sum(norPop-norSumWAGEA(:,3))/sum(norPop);
format long
GiniWAGE

%%%%%%%%%%%%%  Calibration and Response  %%%%%%%%%%%%%%%

%calculate wage rate before policy

wagerate(:,1) = WAGE(:,1)./L(:,1);

% calculate the alpha in this system
alpha = zeros(N,1);
%A = zeros(N,1);  %code for checking errors.
%B = zeros(N,1);
%A = (L(:,1).*wagerate(:,1)-T(:,1)+r(1)*s(:,1));
%B = (wagerate(:,1)-T(:,1)+r(1)*s(:,1));
alpha(:,1) = (L(:,1).*wagerate(:,1)-T(:,1)+r(1)*s(:,1))./(wagerate(:,1)-T(:,1)+r(1)*s(:,1));

%%%% Drop The NaN Values %%%% 
%Contains alpha(1 column), L(3 columns), wagerate(2 columns), Tax(2 columns), saving(1 column) and ID(1 column).

Droppingdata = [alpha,L,wagerate,T,s,ID',WAGE(:,1)];

Droppingdata(isnan(Droppingdata(:,1)),:)=[]; %Drop the NaN value

M = size(Droppingdata);
M = M(1); % Get the length of New data.

alphaNoNaN = Droppingdata(:,1);
LNoNaN = Droppingdata(:,2:4);
wagerateNoNaN = Droppingdata(:,5:6);
TNoNaN = Droppingdata(:,7:8);
sNoNaN = Droppingdata(:,9);
IDNoNaN = Droppingdata(:,10);
WAGENoNaN = Droppingdata(:,11);

alphabar = mean(alphaNoNaN); % Calculate alphabar

regy = wagerateNoNaN(:,1)-(TNoNaN(:,1)-r(1)*sNoNaN(:,1)./(LNoNaN(:,1)));
regx = (wagerateNoNaN(:,1)-TNoNaN(:,1)+r(1)*sNoNaN(:,1))./L(:,1);

[b,bint,re,rint,stats] = regress(regy,regx); %estimate the alpha

%shock of wagerate (Contain NaN)
for i=1:N
wagerate(i,2) = wagerate(i,1); %No Shock
%wagerate(i,2) = wagerate(i,1)*(1+normrnd(0,0.1)); %Normal Distribution Shock
end

display('ccccc')

%shock of wagerate (Exclude NaN)
for i=1:M
wagerateNoNaN(i,2) = wagerateNoNaN(i,1); %No Shock
%wagerate(i,2) = wagerate(i,1)*(1+normrnd(0,0.1)); %Normal Distribution Shock
end

%calculate new L with individual alpha(contain NaN)

L(:,2)= (alpha(:,1).*wagerate(:,2)+(1-alpha(:,1)).*T(:,1)-r(1,2).*s(:,1)+alpha(:,1).*r(1,2).*s(:,1))./wagerate(:,2);
L(:,3)= (alpha(:,1).*wagerate(:,2)+(1-alpha(:,1)).*T(:,2)-r(1,2).*s(:,1)+alpha(:,1).*r(1,2).*s(:,1))./wagerate(:,2);

%calculate new L with alphabar (Exclude NaN data)

LbarNoNaN(:,2)= (alphabar*wagerateNoNaN(:,2)+(1-alphabar)*TNoNaN(:,1)-r(1,2)*sNoNaN(:,1)+alphabar*r(1,2)*sNoNaN(:,1))./wagerateNoNaN(:,2);
LbarNoNaN(:,3)= (alphabar*wagerateNoNaN(:,2)+(1-alphabar)*TNoNaN(:,2)-r(1,2)*sNoNaN(:,1)+alphabar*r(1,2)*sNoNaN(:,1))./wagerateNoNaN(:,2);

%calculate new L with estimated alpha (b)(Exclude NaN data)

LbNoNaN(:,2)= (b*wagerateNoNaN(:,2)+(1-b)*TNoNaN(:,1)-r(1,2)*sNoNaN(:,1)+b*r(1,2)*sNoNaN(:,1))./wagerateNoNaN(:,2);
LbNoNaN(:,3)= (b*wagerateNoNaN(:,2)+(1-b)*TNoNaN(:,2)-r(1,2)*sNoNaN(:,1)+b*r(1,2)*sNoNaN(:,1))./wagerateNoNaN(:,2);

%calculate new L with individual alpha (Exclude NaN data)

LNoNaN(:,2)= (alphaNoNaN(:,1).*wagerateNoNaN(:,2)+(1-alphaNoNaN(:,1)).*TNoNaN(:,1)-r(1,2).*sNoNaN(:,1)+alphaNoNaN(:,1).*r(1,2).*sNoNaN(:,1))./wagerateNoNaN(:,2);
LNoNaN(:,3)= (alphaNoNaN(:,1).*wagerateNoNaN(:,2)+(1-alphaNoNaN(:,1)).*TNoNaN(:,2)-r(1,2).*sNoNaN(:,1)+alphaNoNaN(:,1).*r(1,2).*sNoNaN(:,1))./wagerateNoNaN(:,2);

%Find the effeincy gain or loss

SumLNoNaN = zeros(1,3);
SumLNoNaN(1) = sum(LNoNaN(:,1));
SumLNoNaN(2) = sum(LNoNaN(:,2));
SumLNoNaN(3) = sum(LNoNaN(:,3));

SumLNoNaN([1 3])

figure(6);
plot(ID,L(:,3),'.b');
title('Response of Labor Time(Individual alpha, Contain NaN)');
axis ([0 N 0.25 0.3]);

figure(7);
plot(IDNoNaN,LNoNaN(:,3),'.b');
title('Response of Labor Time(Individual alpha, Exclude NaN)');
axis ([0 M 0.25 0.3]);

wagealphaNoNaN = [WAGENoNaN(:,1),alphaNoNaN(:,1)]; % Create a matrix to connect two variablles
wagealphaNoNaNA = sortrows(wagealphaNoNaN,1); %Sort them by wage by ascending

figure(8);
plot(wagealphaNoNaNA(:,1),wagealphaNoNaNA(:,2),'.b');
title('Relation Between Wage and Individual Alpha');
axis([0 500000 0.2 0.6])
xlabel('wage'); ylabel('alpha')
curvefitwage = wagealphaNoNaNA(:,1);
curvefitalpha = wagealphaNoNaNA(:,2);
fitPop = [1:1:M];
fitPop = fitPop';
Cfitwagealpha = regress(curvefitalpha,curvefitwage);
Cfitpopalpha = regress(curvefitalpha,fitPop);
% devide total population into groups

allgroupwage = wagealphaNoNaNA(:,1);
allgroupalpha = wagealphaNoNaNA(:,2);

m = floor(M/G); % # of individuals in each group, may not devide perfectly
groupwage = zeros(m,G-1);
groupalpha = zeros(m,G-1);

lastgroupwage = allgroupwage(m*G-G:M,1);
lastgroupalpha = allgroupalpha(m*G-G:M,1);

for i = 1:G-1
    groupwage(:,i) = allgroupwage((i-1)*m+1:i*m,1);
    groupalpha(:,i) = allgroupalpha((i-1)*m+1:i*m,1);
end

groupalphabar = zeros(G,1);

for i = 1:G-1
    groupalphabar(i) = mean(groupalpha(:,i));
end

groupalphabar(G) = mean(lastgroupalpha);


wagelabor = [WAGE(:,1),L(:,3)];
wagelaborNoNaN = [WAGENoNaN(:,1),LNoNaN(:,3)];
wagelaborbarNoNaN = [WAGENoNaN(:,1),LbarNoNaN(:,3)];
wagelaborbNoNaN = [WAGENoNaN(:,1),LbNoNaN(:,3)];

wagelaborA = sortrows(wagelabor,1); %Sort the Labor response by ascending by column 1
wagelaborNoNaNA = sortrows(wagelaborNoNaN,1); %Same as above
wagelaborbarNoNaNA = sortrows(wagelaborbarNoNaN,1); %Same as above
wagelaborbNoNaNA = sortrows(wagelaborbNoNaN,1); %Same as above

figure(9);
subplot(2,1,1);
plot(wagelaborA(:,2),'.b');
title('Response of L Sorted by Ascending Wealth (individual alpha, Contain NaN)');
subplot(2,1,2);
plot(wagelaborA(:,1),wagelaborA(:,2),'.b');

figure(10);
subplot(2,1,1);
plot(wagelaborbarNoNaNA(:,2),'.b');
title('Response of L Sorted by Ascending Wealth (Fixed alpha, Exclude NaN)');
subplot(2,1,2);
plot(wagelaborbarNoNaNA(:,1),wagelaborbarNoNaNA(:,2),'.b');

figure(11);
subplot(2,1,1);
plot(wagelaborNoNaNA(:,2),'.b');
title('Response of L Sorted by Ascending Wealth (individual alpha, Exclude NaN)');
subplot(2,1,2);
plot(wagelaborNoNaNA(:,1),wagelaborNoNaNA(:,2),'.b');

figure(12);
plot(wagelaborbarNoNaNA(:,1),wagelaborbarNoNaNA(:,2),'.b');
title('Zoom of Response of L Sorted by Ascending Wealth (Fixed alpha, Exclude NaN)');
axis([0 800000 0.25 0.355]);

figure(13);
plot(wagelaborNoNaNA(:,1),wagelaborNoNaNA(:,2),'.b');
title('Zoom of Response of L Sorted by Ascending Wealth (individual alpha, Exclude NaN)');
axis([0 300000 0.25 0.3]);

hi = linspace(0,500000,50);
ww = hist(WAGE(:,1),hi);
ww = ww/length(WAGE(:,1));

figure(14);
plot(hi,ww);
axis([0 500000 0 0.25]);

%%%%%%%%

%hi2 = linspace(-1000,5000000,50);
%ww2 = hist(Wealth(:,1),hi2);
%ww2 = ww2/length(Wealth(:,1));


%figure(15);
%plot(hi2,ww2);
%axis([-100000 5000000 0 0.25]);


%%%%%%%%%
%hi3 = linspace(0,500000,50);
%ww3 = hist(WAGENoNaN(:,1),hi3);
%ww3 = ww3/length(WAGENoNaN(:,1));

%figure(16);
%plot(hi3,ww3);
%axis([0 500000 0 0.20]);

figure(15);
h1 = histogram(WAGENoNaN(:,1),[0 0:10000:480000 480000]);
title('Frequency distribution histogram of Pre-Tax Income')
xlabel('Pre-Tax Income');ylabel('Frequency')

figure(16)
h2 = histogram(Wealth(:,1),[-200000 -200000:100000:10000000]);
title('Frequency distribution histogram of Pre-Tax Wealth')
xlabel('Pre-Tax Wealth');ylabel('Frequency')

figure(17);
subplot(2,1,1);
plot(wagelaborbNoNaNA(:,2),'.b');
title('Response of L (regression alpha)');
xlabel('Ascending individuals'); ylabel('L*(New)')
axis([0 12049 0.2 0.4]);
subplot(2,1,2);
plot(wagelaborbNoNaNA(:,1),wagelaborbNoNaNA(:,2),'.b');
xlabel('wealth'); ylabel('L*(New)')
axis([0 1000000 0.2 0.4]);

fitwealthb=wagelaborbNoNaNA(:,1);
fitLb = wagelaborbNoNaNA(:,2);
CfitLWb = regress(fitLb,fitwealthb);
CfitLPb = regress(fitLb,fitPop);

figure(18);
subplot(2,1,1);
plot(wagelaborbarNoNaNA(:,2),'.b');
title('Response of L (average alpha)');
xlabel('Ascending individuals'); ylabel('L*(New)')
axis([0 12049 0.2 0.4]);
subplot(2,1,2);
plot(wagelaborbarNoNaNA(:,1),wagelaborbarNoNaNA(:,2),'.b');
xlabel('wealth'); ylabel('L*(New)')
axis([0 1000000 0.2 0.4]);

fitwealthbar=wagelaborbarNoNaNA(:,1);
fitLbar = wagelaborbarNoNaNA(:,2);
CfitLWbar = regress(fitLbar,fitwealthbar);
CfitLPbar = regress(fitLbar,fitPop);

disp('time elaps is');
disp(cputime-t);